# import rclpy
# from rclpy.node import Node
# from std_msgs.msg import Float64MultiArray
# from sensor_msgs.msg import Imu
# from rclpy.qos import QoSProfile, ReliabilityPolicy
# import math
# import pygame

# class PS4SwerveTeleop:
#     def __init__(self, parent_node):
#         pygame.init()
#         pygame.joystick.init()
#         if pygame.joystick.get_count() == 0:
#             parent_node.get_logger().error("Không tìm thấy tay cầm!")
#             self.joy = None
#         else:
#             self.joy = pygame.joystick.Joystick(0)
#             self.joy.init()

#     def get_analog_values(self):
#         pygame.event.pump()
#         if not self.joy: return 0.0, 0.0, 0.0, False
        
#         # Thêm kiểm tra nút Options (nút số 9 trên PS4) để Reset Gyro
#         reset_gyro = self.joy.get_button(9) 
        
#         ly = -self.joy.get_axis(0) if abs(self.joy.get_axis(0)) > 0.05 else 0.0
#         lx = -self.joy.get_axis(1) if abs(self.joy.get_axis(1)) > 0.05 else 0.0
#         az = -self.joy.get_axis(3) if abs(self.joy.get_axis(3)) > 0.1 else 0.0
#         return lx, ly, az, reset_gyro

# class SwerveTestNode(Node):
#     def __init__(self):
#         super().__init__('swerve_test_node')
#         self.teleop_tool = PS4SwerveTeleop(self)
        
#         qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=10)
#         self.imu_sub = self.create_subscription(Imu, '/imu', self.imu_callback, qos)
        
#         self.steer_pub = self.create_publisher(Float64MultiArray, '/steer_controller/commands', 10)
#         self.drive_pub = self.create_publisher(Float64MultiArray, '/drive_controller/commands', 10)
        
#         self.raw_yaw = 0.0
#         self.yaw_offset = 0.0
#         self.timer = self.create_timer(0.02, self.control_loop)
#         self.get_logger().info("Swerve FRC Field-Oriented Snap Mode Ready!")

#     def imu_callback(self, msg):
#         q = msg.orientation
#         siny_cosp = 2 * (q.w * q.z + q.x * q.y)
#         cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
#         self.raw_yaw = math.atan2(siny_cosp, cosy_cosp)

#     def control_loop(self):
#         vx_raw, vy_raw, wz = self.teleop_tool.get_analog_values()[:3]
#         reset_request = self.teleop_tool.get_analog_values()[3]

#         if reset_request:
#             self.yaw_offset = self.raw_yaw
#             self.get_logger().info("Gyro Reset!")

#         # 1. Góc Robot hiện tại (Radian)
#         theta = self.raw_yaw - self.yaw_offset
        
#         # 2. KHÓA HƯỚNG JOYSTICK (Snap to Axis)
#         # Chúng ta khóa hướng của Joystick TRƯỚC khi xoay nó vào hệ tọa độ robot
#         input_mag = math.sqrt(vx_raw**2 + vy_raw**2)
#         if input_mag > 0.15:
#             # Góc người lái muốn đi trên sân (tuyệt đối)
#             # Giả sử đẩy lên là North (0 rad), gạt trái là West (pi/2 rad)
#             input_dir_raw = math.atan2(vy_raw, vx_raw)
            
#             # Khóa hướng vào các trục 0, 90, 180, 270 độ
#             snap_angle = (math.pi / 2) * round(input_dir_raw / (math.pi / 2))
            
#             # 3. BIẾN ĐỔI NGƯỢC (Field to Robot conversion)
#             # Để robot đi thẳng hướng snap_angle trên sân, 
#             # nó phải đi hướng (snap_angle - theta) so với thân nó.
#             target_dir_robot = snap_angle - theta
            
#             vx_fixed = input_mag * math.cos(target_dir_robot)
#             vy_fixed = input_mag * math.sin(target_dir_robot)
#         else:
#             vx_fixed, vy_fixed = 0.0, 0.0

#         # 4. SWERVE KINEMATICS (ABCD)
#         L, W = 0.7, 0.7
#         R = math.sqrt(L**2 + W**2)

#         # Chú ý: Thành phần wz phải được giữ nguyên dấu để tạo mô-men xoay
#         A = vx_fixed - wz * (L / R)
#         B = vx_fixed + wz * (L / R)
#         C = vy_fixed - wz * (W / R)
#         D = vy_fixed + wz * (W / R)

#         # ... (Phần tính s1..s4, a1..a4 như cũ)

#         # Tính toán Speed và Angle (Khớp với URDF của bạn)
#         s = [math.sqrt(B**2 + D**2), math.sqrt(A**2 + D**2), 
#              math.sqrt(B**2 + C**2), math.sqrt(A**2 + C**2)]
        
#         a = [math.atan2(B, -D), math.atan2(A, -D), 
#              math.atan2(B, -C), math.atan2(A, -C)]

#         # Normalize tốc độ
#         max_s = max(s)
#         if max_s > 1.0:
#             s = [val / max_s for val in s]

#         # Publish dữ liệu
#         drive_msg = Float64MultiArray()
#         steer_msg = Float64MultiArray()
#         scale = 50.0 # Tăng tốc độ scale để robot Gazebo chạy bốc hơn
        
#         drive_msg.data = [val * scale for val in s]
#         steer_msg.data = a
        
#         self.drive_pub.publish(drive_msg)
#         self.steer_pub.publish(steer_msg)

#         # Log góc để kiểm tra hướng Bắc
#         self.get_logger().info(f"Heading: {math.degrees(theta):.1f}°", throttle_duration_sec=0.5)

# # (Hàm main giữ nguyên)
# def main(args=None):
#     rclpy.init(args=args)
#     node = SwerveTestNode()
#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         pass
#     finally:
#         node.destroy_node()
#         rclpy.shutdown()

# if __name__ == '__main__':
#     main()
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import Imu
from rclpy.qos import QoSProfile, ReliabilityPolicy
import math
import pygame


class PS4SwerveTeleop:
    def __init__(self, parent_node):
        pygame.init()
        pygame.joystick.init()
        if pygame.joystick.get_count() == 0:
            parent_node.get_logger().error("Không tìm thấy tay cầm!")
            self.joy = None
        else:
            self.joy = pygame.joystick.Joystick(0)
            self.joy.init()
            parent_node.get_logger().info(f"Tay cầm: {self.joy.get_name()}")

    def get_analog_values(self):
        pygame.event.pump()
        if not self.joy:
            return 0.0, 0.0, 0.0, False

        def axis(i, dead):
            v = self.joy.get_axis(i)
            return v if abs(v) > dead else 0.0

        reset_gyro = bool(self.joy.get_button(9))   # Options button

        # Cần TRÁI:  axis 0 = X (strafe), axis 1 = Y (tiến/lùi, đảo dấu)
        # Cần PHẢI:  axis 3 = X (xoay) ← giữ nguyên theo code gốc
        lx = -axis(1, 0.05)   # tiến (+) / lùi (-)
        ly = -axis(0, 0.05)   # trái (+) / phải (-)
        az =  axis(3, 0.10)   # xoay

        return lx, ly, az, reset_gyro


class SwerveTestNode(Node):
    def __init__(self):
        super().__init__('swerve_test_node')
        self.teleop_tool = PS4SwerveTeleop(self)

        qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=10)
        self.imu_sub = self.create_subscription(Imu, '/imu', self.imu_callback, qos)

        self.steer_pub = self.create_publisher(Float64MultiArray, '/steer_controller/commands', 10)
        self.drive_pub = self.create_publisher(Float64MultiArray, '/drive_controller/commands', 10)

        self.raw_yaw   = 0.0
        self.yaw_offset = 0.0
        self.cur_angles = [0.0, 0.0, 0.0, 0.0]   # góc bánh xe hiện tại

        self.timer = self.create_timer(0.02, self.control_loop)
        self.get_logger().info("Swerve Field-Oriented Ready!")
        self.get_logger().info("  Cần TRÁI  → di chuyển  |  Cần PHẢI → xoay")
        self.get_logger().info("  Options   → reset gyro")

    def imu_callback(self, msg):
        q = msg.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.raw_yaw = math.atan2(siny_cosp, cosy_cosp)

    def control_loop(self):
        vx_raw, vy_raw, wz, reset_request = self.teleop_tool.get_analog_values()

        if reset_request:
            self.yaw_offset = self.raw_yaw
            self.get_logger().info("Gyro Reset!")

        theta = self.raw_yaw - self.yaw_offset

        # ── Field-Oriented (xoay vector tịnh tiến theo heading robot) ─────
        #
        # BUG CŨ: dùng snap_angle = round(atan2(vy,vx)/90°)*90°
        #   → khi vx=vy=0:  atan2(0,0)=0  → snap về Bắc → robot drift khi chỉ xoay!
        #   → khi wz≠0:     theta thay đổi từng frame → snap_angle-theta nhảy loạn!
        #
        # FIX: field-to-robot rotation thuần túy (ma trận xoay 2D)
        #   [vx_r]   [ cos(-θ)  -sin(-θ) ] [vx_raw]
        #   [vy_r] = [ sin(-θ)   cos(-θ) ] [vy_raw]

        cos_t = math.cos(-theta)
        sin_t = math.sin(-theta)
        vx_r =  vx_raw * cos_t - vy_raw * sin_t
        vy_r =  vx_raw * sin_t + vy_raw * cos_t

        # ── Swerve Kinematics ─────────────────────────────────────────────
        L, W = 0.7, 0.7
        R = math.sqrt(L**2 + W**2)

        A = vx_r - wz * (L / R)
        B = vx_r + wz * (L / R)
        C = vy_r - wz * (W / R)
        D = vy_r + wz * (W / R)

        speeds = [
            math.hypot(B,  D),   # FL
            math.hypot(A,  D),   # FR
            math.hypot(B,  C),   # RL
            math.hypot(A,  C),   # RR
        ]
        angles = [
            math.atan2(B, -D),   # FL  (dấu âm giữ nguyên theo URDF gốc)
            math.atan2(A, -D),   # FR
            math.atan2(B, -C),   # RL
            math.atan2(A, -C),   # RR
        ]

        # ── Normalize tốc độ ──────────────────────────────────────────────
        max_s = max(speeds)
        if max_s > 1.0:
            speeds = [v / max_s for v in speeds]

        # ── Wheel-flip optimization ───────────────────────────────────────
        # Thay vì quay bánh 180°, đảo dấu tốc độ + quay ≤ 90°
        final_speeds = []
        final_angles = []
        for i, (spd, ang) in enumerate(zip(speeds, angles)):
            delta = ang - self.cur_angles[i]
            delta = (delta + math.pi) % (2 * math.pi) - math.pi   # chuẩn hóa (-π, π]
            if abs(delta) > math.pi / 2:
                delta -= math.copysign(math.pi, delta)
                spd = -spd
            self.cur_angles[i] += delta
            final_speeds.append(spd)
            final_angles.append(self.cur_angles[i])

        # ── Publish ───────────────────────────────────────────────────────
        scale = 50.0
        drive_msg = Float64MultiArray()
        steer_msg = Float64MultiArray()
        drive_msg.data = [v * scale for v in final_speeds]
        steer_msg.data = final_angles

        self.drive_pub.publish(drive_msg)
        self.steer_pub.publish(steer_msg)

        self.get_logger().info(
            f"θ={math.degrees(theta):6.1f}° | "
            f"vx={vx_raw:.2f} vy={vy_raw:.2f} wz={wz:.2f}",
            throttle_duration_sec=0.5,
        )


def main(args=None):
    rclpy.init(args=args)
    node = SwerveTestNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        pygame.quit()


if __name__ == '__main__':
    main()