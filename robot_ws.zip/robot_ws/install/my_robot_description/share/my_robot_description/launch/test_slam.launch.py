import os
import xacro
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, TimerAction, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    # Sử dụng tên package của bạn
    pkg_name = 'my_robot_description'
    pkg_share = get_package_share_directory(pkg_name)
    
    # 1. Đường dẫn file
    urdf_path = os.path.join(pkg_share, 'urdf', 'robot.urdf')
    # Đảm bảo bạn đã đặt file mapv2.sdf vào thư mục worlds trong package
    world_file = os.path.join(pkg_share, 'worlds', 'maprbc.sdf')
    
    # Đọc file URDF qua xacro
    doc = xacro.process_file(urdf_path)

    # 2. Định nghĩa Bridge (Sửa lại kiểu Clock cho chuẩn Fortress)
    gz_ros_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            '/odom@nav_msgs/msg/Odometry[ignition.msgs.Odometry',
            '/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/imu@sensor_msgs/msg/Imu[ignition.msgs.IMU',
            '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
        ],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    # 3. Khai báo các hành động trả về
    return LaunchDescription([
        # Robot State Publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{
                'robot_description': doc.toxml(), 
                'use_sim_time': True
            }]
        ),

        # Gazebo Ignition - Chỉ sử dụng 1 cách khởi động (IncludeLaunchDescription)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')
            ),
            # Dùng f-string để nối chuỗi đường dẫn an toàn
            launch_arguments={'gz_args': f"-r {world_file}"}.items(),
        ),

        # Spawn Robot
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-topic', 'robot_description', '-name', 'swerve_robot', '-z', '0.2'],
            output='screen'
        ),

        # Bridge
        gz_ros_bridge,

        # Controllers (Sử dụng TimerAction để đợi Gazebo load xong)
        TimerAction(
            period=10.0,
            actions=[
                Node(package="controller_manager", executable="spawner", arguments=["joint_state_broadcaster"]),
                Node(package="controller_manager", executable="spawner", arguments=["steer_controller"]),
                Node(package="controller_manager", executable="spawner", arguments=["drive_controller"]),
            ]
        )
    ])
