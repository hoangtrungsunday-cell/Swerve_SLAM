import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    # 1. Khai báo các đường dẫn
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')
    pkg_share = get_package_share_directory('my_robot_description')
    urdf_file = os.path.join(pkg_share, 'urdf', 'swerve.urdf')

    # 2. Đọc nội dung URDF
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()

    # 3. Robot State Publisher (TF nội bộ robot)
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_desc, 'use_sim_time': True}]
    )

    # 4. Mở Gazebo Sim
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': '-r empty.sdf'}.items(),
    )

    # 5. Spawn Robot (Đã sửa từ 'args' thành 'arguments')
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-topic', 'robot_description', '-name', 'swerve', '-z', '0.1'],
        output='screen',
    )

    # 6. BỘ CẦU NỐI (Bridge) - ĐÃ FIX REMAPPING ĐỂ HIỆN TF ODOM
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            # Kéo dữ liệu odom và tf từ topic có tên của model sang topic chuẩn ROS
            '/model/swerve/odometry@nav_msgs/msg/Odometry[ignition.msgs.Odometry',
            '/model/swerve/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            '/model/swerve/joint_state@sensor_msgs/msg/JointState[ignition.msgs.Model',
            '/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
            '/cmd_vel@geometry_msgs/msg/Twist]ignition.msgs.Twist'
        ],
        remappings=[
            ('/model/swerve/odometry', '/odom'),
            ('/model/swerve/tf', '/tf'),
            ('/model/swerve/joint_state', '/joint_states')
        ],
        output='screen'
    )

    return LaunchDescription([
        robot_state_publisher,
        gazebo,
        spawn_robot,
        bridge,
    ])
