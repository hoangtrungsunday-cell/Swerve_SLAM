import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():
    # Đường dẫn URDF
    try:
        pkg_path = get_package_share_directory('my_robot_description')
        urdf_file = os.path.join(pkg_path, 'urdf', 'robot.urdf')
    except:
        urdf_file = os.path.join(os.path.expanduser('~'), 
                                 'robot_ws/src/my_robot_description/urdf/robot.urdf')
    
    # Đọc URDF
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()
    
    # Khởi động Ignition Gazebo Fortress
    world_file = os.path.join(pkg_path, 'worlds', 'mapv2.sdf')

    ign_gazebo = ExecuteProcess(
	    cmd=['ign', 'gazebo', world_file, '-r'],
	    output='screen'
	)

    
    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_desc,
            'use_sim_time': True
        }]
    )
    
    # Bridge (dùng ros_ign_bridge cho Fortress)
    bridge = Node(
        package='ros_ign_bridge',
        executable='parameter_bridge',
        arguments=['/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock'],
        output='screen',
        parameters=[{'use_sim_time': True}]
    )
    
    # Spawn robot sau 4 giây (đợi Gazebo khởi động xong)
    spawn_entity = ExecuteProcess(
        cmd=[
            'bash', '-c',
            f'sleep 4 && ign service -s /world/rbc_soccer_field/create '
            f'--reqtype ignition.msgs.EntityFactory '
            f'--reptype ignition.msgs.Boolean '
            f'--timeout 1000 '
            f'--req "sdf_filename: \\"{urdf_file}\\", '
            f'name: \\"my_robot\\", '
            f'pose: {{position: {{z: 0.5}}}}"'
        ],
        output='screen',
        shell=False
    )
    
    return LaunchDescription([
        ign_gazebo,
        bridge,
        robot_state_publisher,
        spawn_entity,
    ])
