include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder = MAP_BUILDER,
  trajectory_builder = TRAJECTORY_BUILDER,
  map_frame = "map",
  tracking_frame = "imu_link",    -- Phải trùng với link của IMU để tránh lỗi colocated
  published_frame = "base_link",
  odom_frame = "odom",
  provide_odom_frame = true,    
  use_odometry = true,         
  use_nav_sat = false,
  use_landmarks = false,
  
  -- Sửa lỗi 'publish_frame_projected_to_2d' not in dictionary
  publish_frame_projected_to_2d = false, 

  num_laser_scans = 1,
  num_multi_echo_laser_scans = 0,
  num_subdivisions_per_laser_scan = 1,
  num_point_clouds = 0,
  lookup_transform_timeout_sec = 1.0, -- Tăng thời gian chờ TF cho ổn định
  submap_publish_period_sec = 0.3,
  pose_publish_period_sec = 5e-3,
  trajectory_publish_period_sec = 20e-3,
  rangefinder_sampling_ratio = 1.,
  odometry_sampling_ratio = 1.,
  fixed_frame_pose_sampling_ratio = 1.,
  imu_sampling_ratio = 1.,
  landmarks_sampling_ratio = 1.,
}

MAP_BUILDER.use_trajectory_builder_2d = true

-- Cấu hình Trajectory cho 2D SLAM
-- 1. Giới hạn khoảng cách tia Lidar để loại bỏ nhiễu gần/xa
TRAJECTORY_BUILDER_2D.min_range = 0.12
TRAJECTORY_BUILDER_2D.max_range = 50.0 -- Tùy vào loại Lidar, đừng để quá xa nếu môi trường rộng

-- 2. Tăng trọng số cho việc khớp các tia Lidar (Giảm nhòe khi xoay)
-- Các giá trị này giúp "khóa" các điểm Lidar vào đúng vị trí cũ
TRAJECTORY_BUILDER_2D.ceres_scan_matcher.translation_weight = 500.
TRAJECTORY_BUILDER_2D.ceres_scan_matcher.rotation_weight = 900. 

-- 3. Cấu hình Submap (Chia nhỏ để tối ưu hóa nhanh hơn)
TRAJECTORY_BUILDER_2D.submaps.num_range_data = 35 -- Giảm từ 90 xuống 35 để đóng vòng nhanh hơn

-- 4. Sử dụng bộ lọc dữ liệu (Làm sạch bản đồ)
TRAJECTORY_BUILDER_2D.voxel_filter_size = 0.025
TRAJECTORY_BUILDER_2D.adaptive_voxel_filter.max_length = 0.5
TRAJECTORY_BUILDER_2D.adaptive_voxel_filter.min_num_points = 200

TRAJECTORY_BUILDER_2D.use_imu_data = false 
TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = true
TRAJECTORY_BUILDER_2D.num_accumulated_range_data = 1

POSE_GRAPH.optimize_every_n_nodes = 35 -- Khớp với số lượng dữ liệu trong submap
POSE_GRAPH.constraint_builder.min_score = 0.65 -- Tăng độ tin cậy để tránh khớp nhầm
POSE_GRAPH.constraint_builder.global_localization_min_score = 0.7
return options