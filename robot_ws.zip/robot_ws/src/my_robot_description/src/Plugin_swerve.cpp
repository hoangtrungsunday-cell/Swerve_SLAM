#include <ignition/gazebo/System.hh>
#include <ignition/plugin/Register.hh>
#include <ignition/gazebo/Model.hh>
#include <ignition/gazebo/components.hh>
#include <ignition/transport/Node.hh>
#include <ignition/msgs/float_v.pb.h>
#include <vector>
#include <cmath>
#include <algorithm>
#include <mutex>

namespace my_namespace {

class MyCustomPlugin :
  public ignition::gazebo::System,
  public ignition::gazebo::ISystemConfigure,
  public ignition::gazebo::ISystemPreUpdate
{
public:
  void Configure(const ignition::gazebo::Entity &_entity,
                 const std::shared_ptr<const sdf::Element> &,
                 ignition::gazebo::EntityComponentManager &_ecm,
                 ignition::gazebo::EventManager &) override
  {
    model = ignition::gazebo::Model(_entity);

    // Danh sách khớp cũ (Swerve) và khớp mới (Legs)
    const std::string q_names[4] = {"q1_joint", "q2_joint", "q3_joint", "q4_joint"};
    const std::string v_names[4] = {"v1_joint", "v2_joint", "v3_joint", "v4_joint"};
    const std::string leg_names[4] = {"leg_1_joint", "leg_2_joint", "leg_3_joint", "leg_4_joint"};

    for(int i = 0; i < 4; i++)
    {
      auto q_ent = model.JointByName(_ecm, q_names[i]);
      auto v_ent = model.JointByName(_ecm, v_names[i]);
      auto leg_ent = model.JointByName(_ecm, leg_names[i]);

      // Khởi tạo Swerve Joints
      if (q_ent != ignition::gazebo::kNullEntity && v_ent != ignition::gazebo::kNullEntity) {
        steerJoints.push_back(q_ent);
        driveJoints.push_back(v_ent);
        _ecm.CreateComponent(q_ent, ignition::gazebo::components::JointPosition());
        _ecm.CreateComponent(q_ent, ignition::gazebo::components::JointVelocityCmd({0}));
        _ecm.CreateComponent(v_ent, ignition::gazebo::components::JointVelocityCmd({0}));
      }

      // Khởi tạo Leg Joints
      if (leg_ent != ignition::gazebo::kNullEntity) {
        legJoints.push_back(leg_ent);
        // Chân cần JointPosition để làm phản hồi (feedback) cho bộ điều khiển P
        _ecm.CreateComponent(leg_ent, ignition::gazebo::components::JointPosition());
        _ecm.CreateComponent(leg_ent, ignition::gazebo::components::JointVelocityCmd({0}));
      }
    }

    node.Subscribe("/swerve_cmd", &MyCustomPlugin::OnCmd, this);
    ignmsg << "Swerve & Legs Plugin loaded. Ready for 12-element arrays." << std::endl;
  }

  void OnCmd(const ignition::msgs::Float_V &_msg)
  {
    // Cấu trúc message mới: [8 phần tử swerve] + [4 phần tử góc chân] = 12 phần tử
    if (_msg.data_size() < 12) return;

    std::lock_guard<std::mutex> lock(dataMutex);
    for(int i = 0; i < 4; i++) {
      targetSteerRad[i] = _msg.data(i * 2) * (M_PI / 180.0);
      targetDriveVel[i] = _msg.data(i * 2 + 1);
      targetLegRad[i] = _msg.data(8 + i) * (M_PI / 180.0); // 4 phần tử cuối là góc chân
    }
  }

  void PreUpdate(const ignition::gazebo::UpdateInfo &,
                 ignition::gazebo::EntityComponentManager &_ecm) override
  {
    double kp_steer = 20.0;
    double kp_leg = 15.0; // Hệ số P cho chân (thường thấp hơn để tránh rung)

    std::lock_guard<std::mutex> lock(dataMutex);

    // 1. Điều khiển Swerve (Giữ nguyên logic cũ)
    for(int i = 0; i < steerJoints.size(); i++) {
        auto pos_comp = _ecm.Component<ignition::gazebo::components::JointPosition>(steerJoints[i]);
        if(pos_comp && !pos_comp->Data().empty()) {
            double error = targetSteerRad[i] - pos_comp->Data()[0];
            while (error > M_PI) error -= 2.0 * M_PI;
            while (error < -M_PI) error += 2.0 * M_PI;
            _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(steerJoints[i], {error * kp_steer});
        }
        _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(driveJoints[i], {targetDriveVel[i]});
    }

    // 2. Điều khiển 4 chân (Mới)
    for(int i = 0; i < legJoints.size(); i++) {
        auto pos_comp = _ecm.Component<ignition::gazebo::components::JointPosition>(legJoints[i]);
        if(pos_comp && !pos_comp->Data().empty()) {
            double current_pos = pos_comp->Data()[0];
            double error = targetLegRad[i] - current_pos;
            
            // Đối với chân (Revolute), không cần Normalize 360 độ như bánh xe
            double leg_v_cmd = error * kp_leg;
            leg_v_cmd = std::clamp(leg_v_cmd, -5.0, 5.0); // Giới hạn tốc độ chân

            _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(legJoints[i], {leg_v_cmd});
        }
    }
  }

private:
  ignition::gazebo::Model model;
  ignition::transport::Node node;
  std::vector<ignition::gazebo::Entity> steerJoints;
  std::vector<ignition::gazebo::Entity> driveJoints;
  std::vector<ignition::gazebo::Entity> legJoints;
  
  double targetSteerRad[4] = {0,0,0,0};
  double targetDriveVel[4] = {0,0,0,0};
  double targetLegRad[4] = {0,0,0,0};
  std::mutex dataMutex;
};

}

IGNITION_ADD_PLUGIN(
    my_namespace::MyCustomPlugin,
    ignition::gazebo::System,
    my_namespace::MyCustomPlugin::ISystemConfigure,
    my_namespace::MyCustomPlugin::ISystemPreUpdate)
