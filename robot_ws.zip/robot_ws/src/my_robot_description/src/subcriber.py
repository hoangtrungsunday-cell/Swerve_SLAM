import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class SwerveCmdSubscriber(Node):
    def __init__(self):
        super().__init__('swerve_cmd_subscriber')

        self.sub = self.create_subscription(
            Float64MultiArray,
            '/swerve_cmd',
            self.cb,
            1   # queue_size = 1
        )

        self.get_logger().info("Swerve CMD Subscriber ready")

    def cb(self, msg):
        data = msg.data

        # Ví dụ decode
        for i in range(4):
            angle = data[i*2]
            speed = data[i*2 + 1]
            self.get_logger().info(
                f"Wheel {i}: angle={angle:.2f}, speed={speed:.2f}"
            )

        legs = data[8:12]
        self.get_logger().info(f"Legs: {legs}")


def main():
    rclpy.init()
    node = SwerveCmdSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
