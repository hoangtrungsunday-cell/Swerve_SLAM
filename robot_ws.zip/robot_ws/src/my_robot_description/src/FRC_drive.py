import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import pygame

class PS4SwerveTeleop(Node):
    def __init__(self):
        super().__init__('ps4_swerve_teleop')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Khởi tạo Pygame để đọc PS4
        pygame.init()
        pygame.joystick.init()
        
        if pygame.joystick.get_count() == 0:
            self.get_logger().error("Không tìm thấy tay cầm PS4! Hãy kết nối qua Bluetooth/USB.")
            exit()
            
        self.joystick = pygame.joystick.Joystick(0)
        self.joystick.init()
        
        # Thông số cấu hình tốc độ
        self.speed_multiplier = 50.0  # m/s
        self.turn_multiplier = 70.0   # rad/s
        
        # Tạo timer gửi data (50Hz = 0.02s) để robot chạy mượt trong Gazebo
        self.timer = self.create_timer(0.02, self.send_cmd_vel)
        self.get_logger().info(f"Đã kết nối: {self.joystick.get_name()}")

    def send_cmd_vel(self):
        pygame.event.pump()
        
        msg = Twist()
        
        # Đọc trục Analog (Lưu ý: Joystick PS4 hướng lên là giá trị âm, nên cần dấu -)
        # Cần trái
        lx = -self.joystick.get_axis(1) # Tiến/Lùi
        ly = -self.joystick.get_axis(0) # Sang ngang (Strafe)
        # Cần phải
        az = -self.joystick.get_axis(3) # Xoay (Rotation)

        # Bộ lọc nhiễu (Deadzone) - Cực kỳ quan trọng cho Swerve
        # Nếu không có cái này, bánh xe sẽ tự xoay hướng dù bạn không chạm cần
        deadzone = 0.1
        
        msg.linear.x = lx * self.speed_multiplier if abs(lx) > deadzone else 0.0
        msg.linear.y = ly * self.speed_multiplier if abs(ly) > deadzone else 0.0
        msg.angular.z = az * self.turn_multiplier if abs(az) > deadzone else 0.0

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = PS4SwerveTeleop()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Đang dừng Teleop...")
    finally:
        pygame.quit()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()