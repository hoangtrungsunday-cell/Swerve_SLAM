import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import math

class Compass(Node):
    def __init__(self):
        super().__init__('compass_node')
        # Lắng nghe topic /imu
        self.sub = self.create_subscription(Imu, '/imu', self.callback, 10)
        self.get_logger().info("Node La bàn đã bật. Đang chờ Bridge...")

    def callback(self, msg):
        # Tính Yaw từ Quaternion
        q = msg.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        
        degree = math.degrees(yaw)
        if degree < 0: degree += 360
        
        # Xử lý bù lật nếu robot báo 180 độ
        print(f"Góc la bàn hiện tại: {degree:.2f}°", end='\r')

def main():
    rclpy.init()
    node = Compass()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
