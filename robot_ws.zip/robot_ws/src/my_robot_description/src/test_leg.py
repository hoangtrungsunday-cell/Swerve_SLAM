# import subprocess
# import time
# import math
# import threading
# import re
# import sys
# import tty
# import termios


# class SwerveSimulationHack:
#     def __init__(self, model_name):
#         self.model_name = model_name
#         self.vx_f = 0.0
#         self.vy_f = 0.0
#         self.omega = 0.0
#         self.heading = 0.0
#         self.running = True

#         # 4 chân độc lập: [Leg1, Leg2, Leg3, Leg4]
#         self.target_legs = [0.0, 0.0, 0.0, 0.0]
#         self.current_legs = [0.0, 0.0, 0.0, 0.0]

#     def get_heading_from_sim(self):
#         cmd = ["ign", "topic", "-e", "-t", f"/model/{self.model_name}/pose", "-n", "1"]
#         while self.running:
#             try:
#                 result = subprocess.run(cmd, capture_output=True, text=True, timeout=0.2)
#                 z_match = re.search(r'z:\s+([-+]?\d*\.\d+|\d+)', result.stdout)
#                 w_match = re.search(r'w:\s+([-+]?\d*\.\d+|\d+)', result.stdout)
#                 if z_match and w_match:
#                     z = float(z_match.group(1))
#                     w = float(w_match.group(1))
#                     self.heading = 2.0 * math.atan2(z, w)
#             except:
#                 pass
#             time.sleep(0.05)

#     def calculate_and_send(self):
#         wheel_pos = [
#             {"x": 0.35, "y": 0.35},
#             {"x": -0.35, "y": 0.35},
#             {"x": -0.35, "y": -0.35},
#             {"x": 0.35, "y": -0.35},
#         ]

#         while self.running:
#             vx_r = self.vx_f * math.cos(self.heading) + self.vy_f * math.sin(self.heading)
#             vy_r = -self.vx_f * math.sin(self.heading) + self.vy_f * math.cos(self.heading)

#             data = []
#             for p in wheel_pos:
#                 vwx = vx_r - self.omega * p["y"]
#                 vwy = vy_r + self.omega * p["x"]
#                 speed = math.sqrt(vwx ** 2 + vwy ** 2)
#                 angle = math.atan2(vwy, vwx) * 180 / math.pi
#                 data.extend([angle, speed])

#             speed = 3.0
#             for i in range(4):
#                 if abs(self.current_legs[i] - self.target_legs[i]) > 0.5:
#                     if self.current_legs[i] < self.target_legs[i]:
#                         self.current_legs[i] += speed
#                     else:
#                         self.current_legs[i] -= speed

#             data.extend([-a for a in self.current_legs])

#             payload = "data: [" + ", ".join([f"{x:.4f}" for x in data]) + "]"
#             try:
#                 subprocess.Popen(
#                     ["ign", "topic", "-t", "/swerve_cmd", "-m", "ignition.msgs.Float_V", "-p", payload],
#                     stdout=subprocess.DEVNULL,
#                     stderr=subprocess.DEVNULL,
#                 )
#             except:
#                 pass
#             time.sleep(0.05)

#     def get_key(self):
#         fd = sys.stdin.fileno()
#         old_settings = termios.tcgetattr(fd)
#         try:
#             tty.setraw(sys.stdin.fileno())
#             ch = sys.stdin.read(1)
#         finally:
#             termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
#         return ch

#     def print_status(self):
#         status = []
#         for i, angle in enumerate(self.target_legs, 1):
#             state = "🔺UP" if angle > 45 else "🔻DOWN"
#             status.append(f"L{i}:{state}")
#         print(f"\r{' | '.join(status)}     ", end="", flush=True)

#     def run(self):
#         print("║   W/S  : Tiến/Lùi                            ")
#         print("║   A/D  : Trái/Phải                           ")
#         print("║   Q/E  : Xoay trái/phải                      ")
#         print("║   X    : Dừng di chuyển                      ")
#         print("║                                               ")
#         print("║   1    : Chân 1 (trước trái)        ")
#         print("║   2    : Chân 2 (trước phải)        ")
#         print("║   3    : Chân 3 (sau trái)          ")
#         print("║   4    : Chân 4 (sau phải)          ")
#         print("║   Z    :Chân 1+3 (cặp trái)        ")
#         print("║   C    :Chân 2+4 (cặp phải)        ")
#         print("║   G    :  4 chân              ")
#         print("║   R    : Reset         ")
#         print("║                                               ")
#         print("║ ESC    : Thoát chương trình                  ")
#         threading.Thread(target=self.get_heading_from_sim, daemon=True).start()
#         threading.Thread(target=self.calculate_and_send, daemon=True).start()

#         try:
#             while self.running:
#                 key = self.get_key()

#                 if key == "w":
#                     self.vx_f = 15.0
#                     self.vy_f = 0.0
#                 elif key == "s":
#                     self.vx_f = -15.0
#                     self.vy_f = 0.0
#                 elif key == "a":
#                     self.vy_f = 15.0
#                     self.vx_f = 0.0
#                 elif key == "d":
#                     self.vy_f = -15.0
#                     self.vx_f = 0.0
#                 elif key == "q":
#                     self.omega = 15.0
#                 elif key == "e":
#                     self.omega = -15.0
#                 elif key == "x":
#                     self.vx_f = self.vy_f = self.omega = 0.0

#                 elif key in ["1", "2", "3", "4"]:
#                     idx = int(key) - 1
#                     self.target_legs[idx] = 90.0 if self.target_legs[idx] < 45 else 0.0
#                     self.print_status()

#                 elif key == "z":
#                     avg_left = (self.target_legs[0] + self.target_legs[2]) / 2
#                     new_val = 90.0 if avg_left < 45 else 0.0
#                     self.target_legs[0] = new_val
#                     self.target_legs[2] = new_val
#                     print(f"\n(1+3):")
#                     self.print_status()

#                 elif key == "c":
#                     if self.target_legs[1] > -45:
#                         new_val = -90.0
#                     else:
#                         new_val = 0.0

#                     self.target_legs[1] = new_val
#                     self.target_legs[3] = new_val

#                     print(f"\n(2+4):")
#                     self.print_status()

#                 elif key == "g":
#                     avg = sum(self.target_legs) / 4
#                     new_val = 90.0 if avg < 45 else 0.0
#                     self.target_legs = [new_val] * 4
#                     self.print_status()

#                 elif key == "r":
#                     self.target_legs = [0.0] * 4
#                     self.print_status()

#                 elif key == "\x1b":
#                     print("\n\nthoát...")
#                     self.running = False

#         except KeyboardInterrupt:
#             print("\n\nCtrl+C")
#         finally:
#             self.running = False
#             time.sleep(0.1)


# if __name__ == "__main__":
#     robot = SwerveSimulationHack(model_name="swerve")
#     robot.run()

import subprocess
import sys, termios, tty

def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

def send_now(data_list):
    # Định dạng chuẩn của Ignition Gazebo
    msg = f"data: [{','.join(map(str, data_list))}]"
    
    # Sử dụng subprocess.DEVNULL để giải phóng tài nguyên ngay lập tức, tránh nghẽn pipe
    subprocess.Popen(
        ['ign', 'topic', '-t', '/swerve_cmd', '-m', 'ignition.msgs.Float_V', '-p', msg],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

print("ĐANG ĐIỀU KHIỂN... (Bấm W/A/S/D)")

try:
    while True:
        key = get_key()
        if key == 'w':
            send_now([0, 10, 0, 10, 0, 10, 0, 10])
        elif key == 's':
            send_now([0, -10, 0, -10, 0, -10, 0, -10])
        elif key == 'a':
            send_now([90, 5, 90, 5, 90, 5, 90, 5])
        elif key == 'd':
            send_now([-90, 5, -90, 5, -90, 5, -90, 5])
        elif key == ' ':
            send_now([0, 0, 0, 0, 0, 0, 0, 0])
        elif key == 'q':
            break
except Exception as e:
    print(f"Lỗi: {e}")