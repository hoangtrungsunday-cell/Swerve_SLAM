#include <ignition/gazebo/System.hh>
#include <ignition/plugin/Register.hh>
#include <ignition/gazebo/Model.hh>
#include <ignition/gazebo/components.hh>
#include <ignition/transport/Node.hh>
#include <ignition/msgs/float_v.pb.h>
#include <vector>
#include <cmath>
#include <algorithm>
#include <mutex>

namespace my_namespace {
    class Swerve_Plugin :
        public ignition::gazebo::System,
        public ignition::gazebo::ISystemConfigure,
        public ignition::gazebo::ISystemPreUpdate

{
    public:
        void Configure(const ignition::gazebo::Entity &_entity,
                       const std::shared_ptr<const sdf::Element> &,
                       ignition::gazebo::EntityComponentManager &_ecm,
                       ignition::gazebo::EventManager &) override
    {
        model = ignition::gazebo::Model(_entity);

        const std::string q_links[4] = {"q1_joint", "q2_joint", "q3_joint", "q4_joint"};
        const std::string v_links[4] = {"v1_joint", "v2_joint", "v3_joint", "v4_joint"};
        // const std::string leg_links[4] = {"leg_1_joint", "leg_2_joint", "leg_3_joint", "leg_4_joint"};

        for (int i=0;i<4;i++) {
            auto q_ent = model.JointByName(_ecm, q_links[i]);
            auto v_ent = model.JointByName(_ecm, v_links[i]);
            if(q_ent != ignition::gazebo::kNullEntity && v_ent != ignition::gazebo::kNullEntity) {
            steerJoints.push_back(q_ent);
            driveJoints.push_back(v_ent);
            _ecm.CreateComponent(q_ent, ignition::gazebo::components::JointPosition());
            _ecm.CreateComponent(q_ent, ignition::gazebo::components::JointVelocityCmd({0}));
            _ecm.CreateComponent(v_ent, ignition::gazebo::components::JointVelocityCmd({0}));
            }
        }
        node.Subscribe("/swerve_cmd", &Swerve_Plugin::OnCmd, this);
    }
    void OnCmd(const ignition::msgs::Float_V &_msg)
    {
        if (_msg.data_size() < 8) return;
        std::lock_guard<std::mutex> lock(dataMutex);
        for (int i=0;i<4;i++) {
            targetSteerRad[i] = _msg.data(i*2) * (M_PI / 180.0);
            targetDriveVel[i] = _msg.data(i*2 + 1);
        }
    }
    void PreUpdate(const ignition::gazebo::UpdateInfo &,
                   ignition::gazebo::EntityComponentManager &_ecm) override
    {
        double kp_steer = 20.0;
        std::lock_guard<std::mutex> lock(dataMutex);
        for (int i=0;i< steerJoints.size();i++) {
            auto pos_comp = _ecm.Component<ignition::gazebo::components::JointPosition>(steerJoints[i]);
            if(pos_comp && !pos_comp->Data().empty()) {
                double error = targetSteerRad[i] - pos_comp->Data()[0];
                while (error > M_PI) error -= 2.0 * M_PI;
                while (error < -M_PI) error += 2.0 * M_PI;
                _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(steerJoints[i], {error * kp_steer});
            }
            _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(driveJoints[i], {targetDriveVel[i]});
    }
        }
        
private:
  ignition::gazebo::Model model;
  ignition::transport::Node node;
  std::vector<ignition::gazebo::Entity> steerJoints;
  std::vector<ignition::gazebo::Entity> driveJoints;
  
  double targetSteerRad[4] = {0,0,0,0};
  double targetDriveVel[4] = {0,0,0,0};
  std::mutex dataMutex;
};
}
IGNITION_ADD_PLUGIN(
    my_namespace::Swerve_Plugin,
    ignition::gazebo::System,
    my_namespace::Swerve_Plugin::ISystemConfigure,
    my_namespace::Swerve_Plugin::ISystemPreUpdate)
