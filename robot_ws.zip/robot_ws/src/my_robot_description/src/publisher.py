import subprocess
import time
import math

HZ = 100
DT = 1.0 / HZ

def publish(cmd):
    """
    cmd: list 12 phần tử
    """
    data = ",".join([str(x) for x in cmd])
    subprocess.Popen([
        "gz", "topic", "-p",
        "-t", "/swerve_cmd",
        "-m", "ignition.msgs.Float_V",
        "-p", f"data:[{data}]"
    ],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL
    )

t = 0.0

while True:
    # -------------------------
    # VÍ DỤ LOGIC ĐIỀU KHIỂN
    # 8 swerve + 4 chân
    # -------------------------

    swerve = [
        30*math.sin(t),  2.0,
        30*math.sin(t),  2.0,
        30*math.sin(t),  2.0,
        30*math.sin(t),  2.0,
    ]

    legs = [
        -45,
        -45,
        -45,
        -45
    ]

    cmd = swerve + legs
    publish(cmd)

    t += 0.05
    time.sleep(DT)


