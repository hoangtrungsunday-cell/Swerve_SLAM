import subprocess
import time
import sys
import serial
import threading

# ================= CẤU HÌNH SERIAL =================
# Kiểm tra đúng cổng ttyUSB của bạn (có thể là /dev/ttyUSB0 hoặc /dev/ttyACM0)
try:
    ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=0.1)
    print("✓ Đã kết nối cổng Serial STM32")
except Exception as e:
    print(f"✗ Không thể kết nối Serial: {e}")
    sys.exit(1)

# ================= THÔNG SỐ KỸ THUẬT =================
G_SIZE = 9  # Kích thước gói tin 9 byte từ STM32
BANH_RANG_NHO = 15
BANH_RANG_TO = 120
HE_SO_GIAM_TOC = BANH_RANG_TO / BANH_RANG_NHO

# Tần số gửi dữ liệu lên Gazebo (20Hz - 50Hz là mượt)
SEND_PERIOD = 0.04  
last_send_time = 0

# Mảng lưu trạng thái 4 bánh: [theta1, v1, theta2, v2, theta3, v3, theta4, v4]
wheels_state = [0.0] * 8
state_lock = threading.Lock()

# Khớp địa chỉ ID từ STM32 với vị trí mảng (Sửa lại cho đúng ID của bạn)
MOTOR_ADDR = {11: 0, 22: 1, 33: 2, 44: 3}

# ================= HÀM GỬI GAZEBO =================
def send_to_gazebo(data):
    """Gửi mảng Float_V lên Ignition Gazebo thông qua CLI"""
    # Định dạng mảng thành chuỗi: data: [1.2, 5.0, ...]
    payload = "data: [" + ", ".join([f"{x:.4f}" for x in data]) + "]"
    cmd = ["ign", "topic", "-t", "/swerve_cmd", "-m", "ignition.msgs.Float_V", "-p", payload]
    
    try:
        # Popen giúp gửi lệnh mà không chặn luồng chính
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        print(f"Lỗi gửi Gazebo: {e}")

# ================= CHUYỂN ĐỔI DỮ LIỆU =================
def convert_to_real_angle(goc_that):
    """
    Chuyển giá trị encoder/xung từ STM32 về góc Độ thực tế
    Dựa trên logic của bạn: goc_that / (HeSoGiamToc * 1.75)
    """
    return goc_that / (HE_SO_GIAM_TOC * 1.75)

def parse_uart_packet(p):
    """Giải mã gói tin 9 byte theo giao thức của bạn"""
    global last_send_time
    
    # Kiểm tra byte đầu (254) và byte cuối (255)
    if p[0] != 254 or p[8] != 255:
        return
    
    addr = p[1]
    if addr not in MOTOR_ADDR:
        return

    wheel_idx = MOTOR_ADDR[addr]

    # Tính toán Góc (Theta)
    # p[2] là HighByte, p[3] là LowByte. Lưu ý: Bạn dùng 254 trong code cũ, thường là 256.
    goc_raw = p[2] * 254 + p[3] 
    goc = convert_to_real_angle(goc_raw)
    
    # Hướng xoay góc (p[4])
    if p[4] == 0:
        goc = -goc

    # Tính toán Vận tốc (Velocity)
    vel = float(p[6])
    # Hướng lăn bánh (p[7])
    if p[7] == 1:
        vel = -vel

    # Cập nhật vào mảng trạng thái chung
    with state_lock:
        wheels_state[wheel_idx * 2] = goc
        wheels_state[wheel_idx * 2 + 1] = vel

        # Kiểm tra tần số gửi để tránh làm nghẽn Gazebo
        now = time.time()
        if now - last_send_time >= SEND_PERIOD:
            send_to_gazebo(wheels_state)
            last_send_time = now

# ================= LUỒNG NHẬN UART =================
def uart_receiver():
    buffer = bytearray()
    print("-> Đang lắng nghe dữ liệu từ STM32...")
    
    while True:
        try:
            if ser.in_waiting:
                buffer.extend(ser.read(ser.in_waiting))

                while len(buffer) >= G_SIZE:
                    # Tìm byte bắt đầu 254
                    if buffer[0] != 254:
                        buffer.pop(0)
                        continue
                    
                    # Cắt lấy gói tin 9 byte
                    pkt = buffer[:G_SIZE]
                    buffer = buffer[G_SIZE:]
                    
                    # Nếu hợp lệ thì giải mã
                    if pkt[8] == 255:
                        parse_uart_packet(pkt)
            
            time.sleep(0.001) # Tránh chiếm dụng CPU
        except Exception as e:
            print(f"Lỗi luồng UART: {e}")
            break

# ================= CHƯƠNG TRÌNH CHÍNH =================
def main():
    # Chạy việc nhận UART trong một luồng riêng
    t = threading.Thread(target=uart_receiver, daemon=True)
    t.start()

    print("--- SWERVE UART TO GAZEBO BRIDGE RUNNING ---")
    print("Nhấn Ctrl+C để dừng.")
    
    try:
        while True:
            # Hiển thị trạng thái bánh xe 1 để debug nhanh
            with state_lock:
                sys.stdout.write(f"\rBánh 1: G={wheels_state[0]:.1f}° V={wheels_state[1]:.1f} | Đang chạy...")
                sys.stdout.flush()
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\nĐang dừng và reset robot...")
        # Gửi lệnh dừng hẳn cho robot trước khi thoát
        send_to_gazebo([0.0] * 8)
        ser.close()

if __name__ == "__main__":
    main()
