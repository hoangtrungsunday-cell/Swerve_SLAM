#include <ignition/gazebo/System.hh>
#include <ignition/gazebo/Model.hh>
#include <ignition/gazebo/components/JointPosition.hh>
#include <ignition/gazebo/components/JointVelocityCmd.hh>
#include <ignition/plugin/Register.hh>

#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>

#include <ignition/math/Vector2.hh>

#include <array>
#include <string>
#include <mutex>
#include <thread>
#include <cmath>
#include <memory>

namespace my_namespace
{

class Swerve_Plugin :
  public ignition::gazebo::System,
  public ignition::gazebo::ISystemConfigure,
  public ignition::gazebo::ISystemPreUpdate
{
public:
  Swerve_Plugin() = default;

  // Destructor để dừng thread ROS an toàn khi tắt mô phỏng
  ~Swerve_Plugin()
  {
    if (executor_)
    {
      executor_->cancel();
    }
    if (ros_thread_.joinable())
    {
      ros_thread_.join();
    }
  }

  // ================= CONFIGURE =================
  void Configure(
    const ignition::gazebo::Entity &_entity,
    const std::shared_ptr<const sdf::Element> &,
    ignition::gazebo::EntityComponentManager &_ecm,
    ignition::gazebo::EventManager &) override
  {
    model_ = ignition::gazebo::Model(_entity);
    if (!model_.Valid(_ecm))
    {
      ignerr << "[Swerve] Invalid model entity\n";
      return;
    }

    // ---------- ROS INIT ----------
    // Đảm bảo rclcpp đã được khởi tạo để tránh lỗi context null
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }

    ros_node_ = std::make_shared<rclcpp::Node>("swerve_plugin");

    cmd_sub_ = ros_node_->create_subscription<geometry_msgs::msg::Twist>(
      "/cmd_vel", 10,
      std::bind(&Swerve_Plugin::OnCmdVel, this, std::placeholders::_1));

    // ---------- JOINT NAMES ----------
    const std::array<std::string, 4> steer_names{
      "q1_joint", "q2_joint", "q3_joint", "q4_joint"};

    const std::array<std::string, 4> drive_names{
      "v1_joint", "v2_joint", "v3_joint", "v4_joint"};

    const std::array<ignition::math::Vector2d, 4> positions {{
      ignition::math::Vector2d( 0.35,  0.35),
      ignition::math::Vector2d(-0.35,  0.35),
      ignition::math::Vector2d( 0.35, -0.35),
      ignition::math::Vector2d(-0.35, -0.35)
    }};

    // ---------- INIT MODULES ----------
    for (size_t i = 0; i < 4; ++i)
    {
      modules_[i].steer = model_.JointByName(_ecm, steer_names[i]);
      modules_[i].drive = model_.JointByName(_ecm, drive_names[i]);
      modules_[i].pos = positions[i];

      if (modules_[i].steer == ignition::gazebo::kNullEntity ||
          modules_[i].drive == ignition::gazebo::kNullEntity)
      {
        ignerr << "[Swerve] Joint " << steer_names[i] << " or " << drive_names[i] << " not found\n";
        return;
      }

      // Khởi tạo components cho ECM
      if (!_ecm.Component<ignition::gazebo::components::JointPosition>(modules_[i].steer))
        _ecm.CreateComponent(modules_[i].steer, ignition::gazebo::components::JointPosition());

      _ecm.CreateComponent(modules_[i].steer, ignition::gazebo::components::JointVelocityCmd({0.0}));
      _ecm.CreateComponent(modules_[i].drive, ignition::gazebo::components::JointVelocityCmd({0.0}));
    }

    // ---------- ROS SPIN THREAD ----------
    // Khởi tạo executor ở đây để tránh lỗi 'failed to create guard condition'
    executor_ = std::make_unique<rclcpp::executors::SingleThreadedExecutor>();
    executor_->add_node(ros_node_);
    ros_thread_ = std::thread([this]() {
      executor_->spin();
    });

    ignmsg << "[Swerve] Plugin loaded successfully (Gazebo Fortress)\n";
  }

  // ================= PRE UPDATE =================
  void PreUpdate(
    const ignition::gazebo::UpdateInfo &,
    ignition::gazebo::EntityComponentManager &_ecm) override
  {
    std::lock_guard<std::mutex> lock(cmd_mutex_);

    // Nếu không có lệnh điều khiển (robot đứng yên), giữ nguyên góc lái hiện tại
    bool is_moving = (std::abs(vx_) > 1e-3 || std::abs(vy_) > 1e-3 || std::abs(wz_) > 1e-3);

    for (auto &m : modules_)
    {
      double steer_vel = 0.0;
      double drive_vel = 0.0;

      if (is_moving)
      {
        // --- Inverse Kinematics ---
        double vx_i = vx_ - wz_ * m.pos.Y();
        double vy_i = vy_ + wz_ * m.pos.X();

        double speed = std::hypot(vx_i, vy_i);
        double target_angle = std::atan2(vy_i, vx_i);

        // --- Read current angle ---
        auto pos_comp = _ecm.Component<ignition::gazebo::components::JointPosition>(m.steer);
        if (pos_comp && !pos_comp->Data().empty())
        {
          double current = pos_comp->Data()[0];
          double err = Normalize(target_angle - current);

          // --- Flip Optimization (Chọn chiều quay ngắn nhất) ---
          if (std::fabs(err) > M_PI / 2.0)
          {
            err = Normalize(err + M_PI);
            speed = -speed;
          }

          steer_vel = kp_ * err;
          drive_vel = speed / wheel_radius_;
        }
      }

      // --- Send commands ---
      _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(m.steer, {steer_vel});
      _ecm.SetComponentData<ignition::gazebo::components::JointVelocityCmd>(m.drive, {drive_vel});
    }
  }

private:
  struct Module
  {
    ignition::gazebo::Entity steer;
    ignition::gazebo::Entity drive;
    ignition::math::Vector2d pos;
  };

  void OnCmdVel(const geometry_msgs::msg::Twist::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(cmd_mutex_);
    vx_ = msg->linear.x;
    vy_ = msg->linear.y;
    wz_ = msg->angular.z;
  }

  static double Normalize(double a)
  {
    while (a > M_PI) a -= 2.0 * M_PI;
    while (a < -M_PI) a += 2.0 * M_PI;
    return a;
  }

  ignition::gazebo::Model model_;
  std::array<Module, 4> modules_;

  // ROS 2 members
  rclcpp::Node::SharedPtr ros_node_;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_sub_;
  std::unique_ptr<rclcpp::executors::SingleThreadedExecutor> executor_;
  std::thread ros_thread_;

  std::mutex cmd_mutex_;
  double vx_{0.0}, vy_{0.0}, wz_{0.0};
  double wheel_radius_{0.07};
  double kp_{10.0}; 
};

} // namespace my_namespace

IGNITION_ADD_PLUGIN(
  my_namespace::Swerve_Plugin,
  ignition::gazebo::System,
  my_namespace::Swerve_Plugin::ISystemConfigure,
  my_namespace::Swerve_Plugin::ISystemPreUpdate)
