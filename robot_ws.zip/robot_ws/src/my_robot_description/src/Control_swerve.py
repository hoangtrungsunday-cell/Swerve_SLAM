# import subprocess
# import time
# import math
# import threading
# import re
# import sys
# import tty
# import termios
# class SwerveSimulation:
#     def __init__(self, model_name):
#         self.model_name = model_name
#         self.vx_f = 0
#         self.vy_f = 0
#         self.omega = 0.0
#         self.heading = 0.0
#         self.running = True

#         self.target_legs  = [0.0, 0.0, 0.0, 0.0]
#         self.current_legs = [0.0, 0.0, 0.0, 0.0]
#     def get_heading_from_sim(self):
#         cmd = ["ign", "topic", "-e", "-t", f"/model/{self.model_name}/pose","-n", "1"]
#         while self.running:
#             try:
#                 result = subprocess.run(cmd, capture_output = True, text = True, timeout = 0.2)
#                 z_match = re.search(r'z:\s+([-+]?\d*\.\d+|\d+)', result.stdout)
#                 w_match = re.search(r'w:\s+([-+]?\d*\.\d+|\d+)', result.stdout)
#                 if z_match and w_match:
#                     z = float(z_match.group(1))
#                     w = float(w_match.group(1))
#                     self.heading = 2.0 * math.atan2(z, w)
#             except:
#                 pass
#         time.sleep(0.05)
#     def calculate_and_send(self):
#         wheel_pos = [
#            {"x": 0.35, "y": 0.35}, 
#            {"x": -0.35, "y": 0.35},
#            {"x": 0.35, "y": -0.35},
#            {"x": -0.35, "y": -0.35},        
#         ]
#         while self.running:
#             vx_r = self.vx_f * math.cos(self.heading) - self.vy_f * math.sin(self.heading)
#             vy_r = self.vx_f * math.sin(self.heading) + self.vy_f * math.cos(self.heading)
#             data = []
#             for p in wheel_pos:
#                 vwx = vx_r - self.omega * p["y"]
#                 vwy = vy_r + self.omega * p["x"]
#                 speed = math.sqrt(vwx ** 2 + vwy ** 2)
#                 angle = math.atan2(vwy, vwx) * 180 / math.pi
#                 data.extend([angle, speed])
#             speed = 3.0
#             for i in range(4):
#                 if abs(self.current_legs[i] - self.target_legs[i]) > 0.5:
#                     if self.current_legs[i] < self.target_legs[i]:
#                         self.current_legs[i] += speed
#                     else:
#                         self.current_legs[i] -= speed
#             data.extend([-a for a in self.current_legs])

#             payload = "data: ["+", ".join([f"{x:.4f}" for x in data]) + "]"
#             try:
#                 subprocess .Popen(
#                     ["ign", "topic", "-t", "/swerve_cmd", "-m", "ignition.msgs.Float_V", "-p", payload],
#                     stdout = subprocess.DEVNULL, 
#                     stderr = subprocess.DEVNULL,
#                 )
#             except:
#                 pass
#             time.sleep(0.5)
#     def get_key(self):
#         fd = sys.stdin.fileno()
#         old_settings = termios.tcgetattr(fd)
#         try:
#             tty.setraw(sys.stdin.fileno())
#             ch = sys.stdin.read(1)
#         finally:
#             termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
#         return ch
#     def print_status(self):
#         status = []
#         for i, angle in enumerate(self.target_legs, 1):
#             state = "Up" if angle > 45 else "Down"
#             status.append(f"L{i}:{state}")
#     def run(self):
#         threading.Thread(target=self.get_heading_from_sim, daemon = True).start()
#         threading.Thread(target=self.calculate_and_send, daemon = True).start()

#         try:
#             while self.running:
#                 key = self.get_key()
#                 if key == "w":
#                     self.vx_f = 15.0
#                     self.vy_f = 0.0
#                 elif key == "\x1b":
#                     print("\n\nthoát...")
#                     self.running = False

#                 elif key == "g":
#                     avg = sum(self.target_legs) / 4
#                     new_val = 90.0 if avg < 45 else 0.0
#                     self.target_legs = [new_val] * 4
#                     self.print_status()
#         except KeyboardInterrupt:
#             print("\n\nCtrl+C")
#         finally:
#             self.running = False
#             time.sleep(0.1)
# if __name__ == "__main__":
#     robot = SwerveSimulation(model_name="swerve")
#     robot.run()            
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import pygame

class PS4ToSwerve(Node):
    def __init__(self):
        super().__init__('ps4_teleop_node')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Khởi tạo Pygame để đọc PS4
        pygame.init()
        pygame.joystick.init()
        
        if pygame.joystick.get_count() == 0:
            self.get_logger().error("Không tìm thấy tay cầm PS4!")
            exit()
            
        self.joystick = pygame.joystick.Joystick(0)
        self.joystick.init()
        
        # Tạo timer để gửi dữ liệu liên tục (20Hz)
        self.timer = self.create_timer(0.05, self.publish_callback)
        self.get_logger().info("Đã bắt đầu đọc PS4 và gửi tới /cmd_vel")

    def publish_callback(self):
        pygame.event.pump()
        
        msg = Twist()
        
        # Ánh xạ Stick trái cho di chuyển (Linear)
        # Trục 1 là Tiến/Lùi, Trục 0 là Sang ngang (Strafe)
        # Lưu ý: Cần đảo dấu (-) vì joystick hướng lên thường là giá trị âm
        msg.linear.x = -self.joystick.get_axis(1) * 1.0  # Max speed 1.0 m/s
        msg.linear.y = -self.joystick.get_axis(0) * 1.0  # Max speed 1.0 m/s (Swerve cần cái này!)
        
        # Ánh xạ Stick phải cho xoay (Angular)
        # Trục 3 thường là xoay ngang của cần phải
        msg.angular.z = -self.joystick.get_axis(3) * 2.0 # Max 2.0 rad/s
        
        # Deadzone lọc nhiễu
        if abs(msg.linear.x) < 0.1: msg.linear.x = 0.0
        if abs(msg.linear.y) < 0.1: msg.linear.y = 0.0
        if abs(msg.angular.z) < 0.1: msg.angular.z = 0.0

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = PS4ToSwerve()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()