# import os
# from launch import LaunchDescription
# from launch_ros.actions import Node
# from ament_index_python.packages import get_package_share_directory

# def generate_launch_description():
#     package_dir = get_package_share_directory('my_robot_description')
#     lua_config_path = os.path.join(package_dir, 'config')
    
#     return LaunchDescription([

#         Node(
#             package='cartographer_ros',
#             executable='cartographer_node',
#             name='cartographer_node',
#             output='screen',
#             parameters=[{'use_sim_time': True}],
#             arguments=[
#                 '-configuration_directory', lua_config_path,
#                 '-configuration_basename', 'my_cartographer.lua'
#             ],
#             remappings=[('/scan', '/scan')]
#         ),
#         Node(
#             package='cartographer_ros',
#             executable='cartographer_occupancy_grid_node',
#             name='occupancy_grid_node',
#             output='screen',
#             parameters=[{'use_sim_time': True}],
#             arguments=['-resolution', '0.05', '-publish_period_sec', '1.0']
#         ),
#     ])
import os
from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    package_dir = get_package_share_directory('my_robot_description')
    lua_config_path = os.path.join(package_dir, 'config')
    
    return LaunchDescription([
        # 1 Node Cartographer
        Node(
            package='cartographer_ros',
            executable='cartographer_node',
            name='cartographer_node',
            output='screen',
            parameters=[{'use_sim_time': True}],
            arguments=[
                '-configuration_directory', lua_config_path,
                '-configuration_basename', 'my_cartographer.lua'
            ],
            # chay robot moi truong thuc te thi dat usesimtime=false
            remappings=[('/scan', '/scan')]
        ),

        # 2
        Node(
            package='cartographer_ros',
            executable='cartographer_occupancy_grid_node',
            name='occupancy_grid_node',
            output='screen',
            parameters=[{'use_sim_time': True}],
            arguments=['-resolution', '0.05', '-publish_period_sec', '0.5'] 
        ),
    ])
