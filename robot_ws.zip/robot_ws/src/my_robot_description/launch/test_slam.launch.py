import os
import xacro
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, TimerAction, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    # Sử dụng tên package 
    pkg_name = 'my_robot_description'
    pkg_share = get_package_share_directory(pkg_name)
    
    # 1. Đường dẫn file
    urdf_path = os.path.join(pkg_share, 'urdf', 'robot.urdf')
    world_file = os.path.join(pkg_share, 'worlds', 'maprbc.sdf')
    
    doc = xacro.process_file(urdf_path)

    # 2.Bridge
    gz_ros_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            '/odom@nav_msgs/msg/Odometry[ignition.msgs.Odometry',
            '/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/imu@sensor_msgs/msg/Imu[ignition.msgs.IMU',
            '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
        ],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    return LaunchDescription([
        # Robot State Publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{
                'robot_description': doc.toxml(), 
                'use_sim_time': True
            }]
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')
            ),

            launch_arguments={'gz_args': f"-r {world_file}"}.items(),
        ),

        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-topic', 'robot_description', '-name', 'swerve_robot', '-z', '0.2'],
            output='screen'
        ),

        gz_ros_bridge,

        TimerAction(
            period=10.0,
            actions=[
                Node(package="controller_manager", executable="spawner", arguments=["joint_state_broadcaster"]),
                Node(package="controller_manager", executable="spawner", arguments=["steer_controller"]),
                Node(package="controller_manager", executable="spawner", arguments=["drive_controller"]),
            ]
        )
    ])
